# Přepracování interiéru Benešovy kovárny – návrh v2

Současné jednotlivé objekty mají použitelnou kvalitu. Hlavní problém je kompozice: velké prázdné plochy, viditelné opakování podlahové textury, prudký přechod mezi dvěma druhy stěny, slabé kontaktní stíny a pracoviště, která vypadají jako samostatné obrázky položené do místnosti.

## Hlavní změny

1. Výheň je zasazená do pravé zadní stěny a měchy jsou k ní fyzicky připojené.
2. Kovadlina, výheň a káď tvoří kompaktní pracovní trojúhelník.
3. Vstupní osa zůstává volná a hráč se dostane ke všem pracovištím bez obcházení překážek.
4. Levá část slouží pro studenou práci, nástroje a železné polotovary.
5. Pravá část je špinavější a teplejší: výheň, uhlí, popel, káď, brus a palivo.
6. Dubový nosný sloup schová přechod mezi omítanou a očazenou stěnou.
7. Podlaha není jedna opakovaná textura. Má základ, kamennou ochrannou plochu u výhně a samostatné vrstvy sazí, okují, vlhka a vyšlapaných cest.
8. Teplé světlo výhně plynule slábne; dveře a malé okno přidávají chladné denní světlo.

## Co opravit nejdříve

- Nahradit sud pod kovadlinou nepravidelným dubovým špalkem.
- Přidat kontaktní stíny pod všechna pracoviště.
- Vytvořit hubici propojující měchy s výhní.
- Zamaskovat přechod materiálů stěny nosným sloupem.
- Přidat čtyři až šest nepravidelných podlahových obtisků místo další velké textury.
- Zmenšit a sjednotit měřítko kádě, brusu a skladových objektů.

## Nové drobné assety

- `smithy_oak_support_post`
- `smithy_shuttered_window`
- `smithy_bellows_nozzle`
- `smithy_wall_shelf_small`
- `smithy_floor_decal_ash`
- `smithy_floor_decal_scale`
- `smithy_floor_decal_wet`
- `smithy_floor_decal_worn_path`

Tyto prvky mají větší dopad než další velký kus nábytku: propojí současné objekty s místností a odstraní dojem koláže.

Soubor `smithy_room_layout_v2.json` je návrhový. Pole `rotation_deg`, `zone`, `layer`, `surface_zones` a složené osvětlení mohou vyžadovat doplnění loaderu, pokud je současná verze ještě nečte.

Finální obrazový návrh je `concept/smithy_interior_redesign_concept_v2_final.png`. Předchozí pracovní návrh zůstává přiložený pouze pro porovnání změny podstavce kovadliny.
